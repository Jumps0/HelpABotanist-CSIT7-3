// Initialize map
const map = L.map('map').setView([56.2639, 9.5018], 7);

// Add OpenStreetMap tiles
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  attribution: '© OpenStreetMap contributors',
  maxZoom: 18,
}).addTo(map);

//      ---------   For plant dropdown ---------------
 
let selectedPlant = null;
let plantNames = []; // Array to store plant names from the header row
let gridSquares = []; // Global array to store grid squares for clearing later

// Function to fetch and parse plant data from CSV
async function fetchPlantData() {
  try {
    const response = await fetch('datagrid.csv');
    const text = await response.text();
    const rows = text.trim().split('\n');

    // Extract header row and plant names
    const headerRow = rows[0].split(',');
    plantNames = headerRow.slice(12).map(name => name.trim());
    console.log("Plant Names:", plantNames);

    // Populate dropdown with plant names
    const dropdown = document.getElementById('dropdown');
    dropdown.innerHTML = ''; // Clear previous items
    plantNames.sort((a, b) => a.localeCompare(b)); // Sort alphabetically
    plantNames.forEach(plant => {
      const item = document.createElement('div');
      item.className = 'dropdown-item';
      item.textContent = plant;
      item.dataset.plant = plant;
      dropdown.appendChild(item);
    });

    // Parse CSV data into an array of objects
    const data = rows.slice(1).map(row => {
      const values = row.split(',');
      const obj = {};
      headerRow.forEach((key, index) => {
        obj[key.trim()] = values[index] ? values[index].trim() : null;
      });
      return obj;
    });

    console.log("Parsed CSV Data:", data); // Debugging
    return data;
  } catch (error) {
    console.error("Error fetching or parsing CSV data:", error);
  }
}

//       --------- HeatMap  as a grid and color defining for Occurrence  ------------

// Clear existing grid squares
function clearGrid() {
  gridSquares.forEach(square => map.removeLayer(square));
  gridSquares = [];
}

let occurrenceLayer = L.layerGroup().addTo(map);
let predictionLayer = L.layerGroup().addTo(map);


// Generate grid cells based on occurrences of the selected plant
function generateGrid(flowerColumn, flowerData) {
  const gridSize = 0.2; // Grid cell size in degrees
  const gridCounts = {}; // Store counts for each grid cell

  // Loop through flower data and calculate occurrences for each grid cell
  flowerData.forEach(row => {
    const lat = parseFloat(row.latitude);
    const lon = parseFloat(row.longitude);
    const occurrence = parseFloat(row[flowerColumn]);

    if (!isNaN(lat) && !isNaN(lon) && !isNaN(occurrence) && occurrence >= 0) {
      // Determine the grid cell based on lat and lon
      const latGrid = Math.floor(lat / gridSize) * gridSize;
      const lonGrid = Math.floor(lon / gridSize) * gridSize;
      const cellKey = `${latGrid},${lonGrid}`; // Unique key for the grid cell
      gridCounts[cellKey] = (gridCounts[cellKey] || 0) + occurrence;
    }
  });

  // Clear previous grid cells
  clearGrid();

  // Create grid cells with color coding based on occurrences
  Object.keys(gridCounts).forEach(cellKey => {
    const [latGrid, lonGrid] = cellKey.split(',').map(Number);
    const count = gridCounts[cellKey];

    // Define color based on count (green to red scale)
    const color = count === 0 ? 'blue' :
                  count <= 2 ? 'green' :
                  count <= 5 ? 'yellow' :
                  count <= 8 ? 'orange' :
                  'red';
                  const square = L.polygon(
                    [
                      [latGrid, lonGrid],                       // Bottom-left
                      [latGrid + gridSize, lonGrid],            // Bottom-right
                      [latGrid + gridSize, lonGrid + gridSize], // Top-right
                      [latGrid, lonGrid + gridSize],            // Top-left
                      [latGrid, lonGrid],                       // Close the square
                    ],
                    {
                      color: 'black', // Border color
                      weight: 0.9,    // Border thickness
                      fillColor: color, // Dynamic fill color
                      fillOpacity: 0.7, // Opacity of the square fill
                    }
                  );
                  // Add a popup with information about the grid cell
                 const popupMessage = `
                <strong>Grid Cell Info:</strong><br>
                 Latitude: ${latGrid.toFixed(2)} to ${(latGrid + gridSize).toFixed(2)}<br>
                  Longitude: ${lonGrid.toFixed(2)} to ${(lonGrid + gridSize).toFixed(2)}<br>
                   Occurrences: ${count}`;
                square.bindPopup(popupMessage);
                // Add the square to the map
                  square.addTo(occurrenceLayer);
                  gridSquares.push(square); // Store the square for later removal
                  
    });
}

//     -----------  Creating Occurrence button and connecting with CSV file ----------

// Handle plant selection and generate grid
function setupSearch(data) {
  const searchButton = document.getElementById('search-button');
  searchButton.addEventListener('click', () => {
    searchButton.classList.add('active-button');
    if (!selectedPlant) {
      alert('Please select a plant.');
      return;
    }
    
    // Filter data for the selected plant with presence >= 1
    const filteredData = data.filter(row => {
      const presence = parseInt(row[selectedPlant], 10);
      return !isNaN(presence) && presence >= 0;
    });

     // Generate the grid based on occurrences
  generateGrid(selectedPlant, filteredData);

    // Calculate the sum of all presences
    const presenceSum = filteredData.reduce((sum, row) => {
      const presence = parseInt(row[selectedPlant], 10);
      return sum + (isNaN(presence) ? 0 : presence);
    }, 0);

    // Update the result message
    const resultElement = document.getElementById('prediction-result');
    resultElement.innerHTML = `Total number of presence from the records for <strong>${selectedPlant}</strong>: <strong>${presenceSum}</strong>`;
  });
}

//     -----------  Creating Prediction button and connecting with backend file ----------

async function setupPredictionButton() {
  const predictionButton = document.getElementById('predictionButton');
  console.log("Prediction Button clicked, connecting to API...");

  predictionButton.addEventListener('click', async () => {
    predictionButton.classList.add('active-button');
    if (!selectedPlant) {
      alert('Please !! select a plant.');
      return;
    }
  
    // Prepare the request data for the prediction
    const requestData = {plant: selectedPlant};// JSON data structure
   
    try {
      // Send a POST request to FastAPI server
      console.log('Sending request to the server...', requestData);
      const response = await fetch('http://localhost:8000/predict', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(requestData), 
      });

      console.log("Selected @Plant:", selectedPlant);
      console.log("Request Data:", requestData);
       
      // Handle the response
        if (!response.ok) {
          throw new Error(`Failed to fetch prediction data: ${response.statusText}`);
      }

      console.log("I'm going to get JSON data ")
      // Handle the response from the backend
      const result = await response.json();
      console.log("Received response:",result); // You can log to check the response
     
      if (!result.heatmap || !Array.isArray(result.heatmap)) {
        console.error("Invalid heatmap data:", result.heatmap);
        alert("No valid heatmap data received.");
        return;
      }
      console.log("Received data:",result.heatmap);
      // Call displayPredictionHeatmap to show the heatmap
      displayPredictionHeatmap(result.heatmap);
    } catch (error) {
      console.error('Prediction request failed:', error);
      alert(`Failed to fetch prediction data: ${error.message}`);
    }
  });
}

//  ------- Longitute and Latitude Validation check with backend data  -----------
 

//   ------- Creating Prediction HeatMap with backend data ----------------- 

function displayPredictionHeatmap(heatmap) {
  clearGrid(); // Clear the old grid
  console.log("Prepareing HeatMap")
  // Here, you can handle how the heatmap is displayed on the map
  if (!Array.isArray(heatmap) || heatmap.length === 0) {
    console.error("Invalid or empty heatmap data:", heatmap);
    return; // Exit the function if the data is invalid or empty
  }
  
  console.log(heatmap,"HeatMap VALUES ")
  const gridSize = 0.2; // Define grid size
  const values = heatmap.map(item => item.intensity);
  const minValue = Math.min(...values);
  const maxValue = Math.max(...values);

   // Handle edge case where all intensity values are the same
  if (minValue === maxValue) {
    console.warn("All intensity values are the same. Adjusting scale.");
    maxValue = minValue + 1; // Prevent zero-range scale
  }
  
  // Define a color scale (e.g., blue to red gradient)
  const colorScale = chroma.scale(['blue', 'green', 'yellow', 'orange', 'red']).domain([minValue, maxValue]);
  
  heatmap.forEach(({ latitude, longitude, intensity }) => {
    console.log(`Processing: Lat=${latitude}, Lon=${longitude}, Intensity=${intensity}`);
  
    const color = colorScale(intensity).hex();
    
   // console.log(`Min Intensity: ${minValue}, Max Intensity: ${maxValue}`);
    //console.log(`Color for intensity ${intensity}: ${color}`);
    const bounds = L.latLngBounds(heatmap.map(({ latitude, longitude }) => [latitude, longitude]));
map.fitBounds(bounds);
    const square = L.polygon(
      [
        [latitude, longitude],
        [latitude + gridSize, longitude],
        [latitude + gridSize, longitude + gridSize],
        [latitude, longitude + gridSize],
        [latitude, longitude],
      ],
      {
        color: 'black',
        weight: 0.9,
        fillColor: color,
        fillOpacity: 0.7,
      }
    );

    square.bindPopup(`
      <strong>Prediction Info:</strong><br>
      Latitude: ${latitude.toFixed(2)}<br>
      Longitude: ${longitude.toFixed(2)}<br>
      Intensity: ${intensity.toFixed(2)}
    `);

    square.addTo(predictionLayer);
    gridSquares.push(square); // Store grid squares for cleanup
  });
}
 

//    --------- Assigning Functions for Occurrence and Prediction buttons  -------------

document.getElementById('predictionButton').addEventListener('click', async () => {
  const heatmap = await setupPredictionButton(); // Fetch prediction data from the backend
  if (heatmap) { 
  displayPredictionHeatmap(heatmap); // Display the heatmap
  }
  else {
    console.error("No heatmap data received.");
  }
});

function setupDropdown() {
    const searchInput = document.getElementById('search-input');
    const dropdown = document.getElementById('dropdown');
  
    // Show dropdown on focus
    searchInput.addEventListener('focus', () => {
      dropdown.classList.add('show');
    });
  
    // Filter dropdown items based on user input
    searchInput.addEventListener('input', (e) => {
      const query = e.target.value.toLowerCase();
      Array.from(dropdown.children).forEach(item => {
        item.style.display = item.textContent.toLowerCase().includes(query) ? 'block' : 'none';
      });
    });
  
    // Handle plant selection from dropdown
    dropdown.addEventListener('click', (e) => {
      if (e.target.classList.contains('dropdown-item')) {
        selectedPlant = e.target.dataset.plant;
        searchInput.value = selectedPlant;
        dropdown.classList.remove('show');
      }
    });
    // Hide dropdown when clicking outside
    document.addEventListener('click', (e) => {
      if (!dropdown.contains(e.target) && !searchInput.contains(e.target)) {
        dropdown.classList.remove('show');
      }
    });
  }

//   -------------  Initializing overall functions  ------------------

// Fetch and display plant data, set up dropdown and search functionality
async function initializeData() {
  const data = await fetchPlantData(); // Fetch and parse CSV
  setupDropdown(); // Setup dropdown functionality
  setupSearch(data); // Setup search and heatmap rendering
  setupPredictionButton(); // event listener for prediction button
}

// Initialize the app
initializeData();
